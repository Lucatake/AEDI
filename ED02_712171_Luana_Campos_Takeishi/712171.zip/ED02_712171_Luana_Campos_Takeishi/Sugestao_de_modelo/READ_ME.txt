
Luana Campos Takeishi _ 712171 _ Estudo Digirido 02
Proposta de método para a junção de todos os programas (exercícios) em um só (Exemplo02). Uso do switch-case, como mostrado no Estudo Dirigido 03. Os exercícios são os propostos a partir do Exemplo0210, que vão de 11-20 mais os extras E1 e E2. 
