
Luana Campos Takeishi _ 712171 _ Estudo Digirido 03
Proposta de método para a junção de todos os programas (exercícios) em um só (Exemplo03). Uso do switch-case, como mostrado no Estudo Dirigido 03. Os exercícios são os propostos a partir do Exemplo0310, que vão de 11-20 mais os extras E1 e E2. 
