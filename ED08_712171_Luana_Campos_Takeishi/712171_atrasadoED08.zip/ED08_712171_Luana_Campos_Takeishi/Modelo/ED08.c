/*
ED08 - v0.0. - 28/09/2020
Author: Henrique Castro E Silva Matricula: 711260
Para compilar em terminal (janela de comandos):

Linux : gcc -o ED08 ED08.c
Windows: gcc -o ED08.exe ED08.c

Para executar em terminal (janela de comandos):
Linux : ./ED08
Windows: ED08
*/

// dependencias
#include "io.h" // para definicoes proprias
#include "gen.h"

//definicao global

void method00()
{

}

void metodo0811()
{
    int quantidade = 0;
    int valor = 0;

    //Garantir quantidade valida
    do
    {
        quantidade = getInt("Entre com quantidade: ");
        if(quantidade <= 0)
        {
            printf("Valor Invalido\n");
        }

    }while(quantidade <= 0);

    int array[quantidade];//criar vetor

    for(int i = 0; i < quantidade; i++)
    {
        do
        {   //declara valores no vetoe, e que sejam validos
            valor = getInt("\nEntre com um valor para o array:");
            if(even(valor) && valor > 0)
            {
                array[i] = valor;
            } else
            {
                printf("Valor nao e positivo ou par\n");
            }
        } while( !even(valor) || valor <=0);
    }
    //printar valores
    for(int i = 0; i < quantidade; i++)
    {
        printf("%d: %d\n", i, array[i]);
    }

}

void Exemplo0811()
{
    metodo0811( );
}

void metodo0812(int * array, char* fileName)
{
    //declarar variaveis
    int len = 0;
    int valor = 0;
    FILE* arquivo = fopen(fileName, "r");

    //descobrir tamanho do vetor no arquivo
    fscanf(arquivo, "%d", &len);

    for(int i = 0; i < len; i++)
    {   //enquanto nao estiver no fim do arquivo
        if(!feof(arquivo))
        {   //ir para a prox linha
            fscanf(arquivo, "%d", &valor);
            //checar se valor e valido
            if(!even(valor) && valor < 0)
            {   //pular valores invalidos
                i--;
            } else
            {   //salvar valores validos
                array[i]= valor;
            }
        }
    }

    fclose(arquivo);

}

void Exemplo0812()
{
    //declarar variaveis
    int len = 0;
    FILE* arquivo = fopen("ARRAY1.txt", "r");

    //descobrir tamanho do array
    fscanf(arquivo, "%d", &len);
    fclose(arquivo);

    if(len <= 0)
    {
        printf("Valor invalido.");
    } else
    {
        int array[len];
        //limpar array
        for(int i = 0; i<len; i++)
        {
            array[i] = 0;
        }

        metodo0812(array, "ARRAY1.txt");
        //printar novo array
        for(int i = 0; i<len; i++)
        {
            printf("%d: %d\n", i, array[i]);
        }
    }

}

void Exemplo0813()
{
    int interMinimo = 0;
    int interMaximo = 0;
    int quantidade = 0;
    FILE* arquivo = fopen("DADOS.txt", "w");

    interMinimo = getInt("Entre com valor minimo do intervalo: ");

    do
    {
        interMaximo = getInt("Entre com valor maximo do intervalo: ");
    } while(interMinimo >= interMaximo);

    do
    {
        quantidade = getInt("Entre com quantidade: ");
    } while(quantidade <= 0);
    fprintf(arquivo, "%d\n", quantidade);

    int array [quantidade];
    srand(time(0));

    for(int i = 0; i < quantidade; i++)
    {
        do
        {
            array [i] = rand() - (RAND_MAX/2);
            //versao alternativa para numero rand
            //OBS.:Versao mais 'light' porem nao inclui o valor do intervalo maximo
            // array [i] = (rand()%((interMaximo - interMinimo)*2)) - (interMaximo - interMinimo) ;
        } while(array[i] < interMinimo || array[i] > interMaximo);

        fprintf(arquivo, "%d\n", array[i]);
    }

    fclose(arquivo);

}

void metodo0814(char* fileName, int* array)
{
    //variaveis
    int len = 0;
    int resp = 0;
    int valor = 0;
    bool validResp = false;
    FILE* arquivo = fopen("DADOS.txt", "r");

    //decobrir tamanho do array
    fscanf(arquivo, "%d", &len);

    //dar valor ao array
    for(int i = 0; i < len; i++)
    {
        fscanf(arquivo, "%d", &valor);
        array[i] = valor;
    }

    //valor base a resposta
    resp = array[0];

    for(int i = 0; i < len; i++)
    {   //se for par
       if(even(array[i]))
        {   //se for o primeiro numero valido
            if(!validResp)
            {
                resp = array[i];
                validResp = true;//variavel de controle (evita casos onde nao ha nenhum numeor par)
            }
            //e menor que a reposta
            if(array[i] <= resp)
            {
                resp = array[i];    //salva o valor
            }
        }
    }

    if(validResp)
    {
        printf("Menor e: %d", resp);
    }else
    {
        printf("Nao ha resposta valida");
    }
    fclose(arquivo);

}

void Exemplo0814()
{
    int len = 0;
    FILE* arquivo = fopen("DADOS.txt", "r");

    fscanf(arquivo, "%d", &len);
    fclose(arquivo);

    int array[len];

    metodo0814("Dados.txt", array);

}

void metodo0815(char* fileName, int* array)
{
    int len = 0;
    int resp = 0;
    int valor = 0;
    bool validResp = false;
    FILE* arquivo = fopen("DADOS.txt", "r");

    fscanf(arquivo, "%d", &len);

    for(int i = 0; i < len; i++)
    {
        fscanf(arquivo, "%d", &valor);
        array[i] = valor;
    }

    resp = array[0];

    for(int i = 1; i < len; i++)
    {
       if(!even(array[i]))
        {
            if(!validResp)
            {
                resp = array[i];
                validResp = true;
            }
            if(array[i] >= resp)
            {
                resp = array[i];
            }
        }
    }

    if(validResp)
    {
        printf("Maior e: %d", resp);
    }else
    {
        printf("Nao ha resposta valida");
    }
}

void Exemplo0815()
{
    int len = 0;
    FILE* arquivo = fopen("DADOS.txt", "r");

    fscanf(arquivo, "%d", &len);
    fclose(arquivo);

    int array[len];

    metodo0815("Dados.txt", array);
}

void lerArquivo(char* fileName, int* array)
{
    FILE* arquivo = fopen(fileName, "r");
    int len = 0;

    fscanf(arquivo, "%d", &len);

    for(int i =0; i<len; i++)
    {
        fscanf(arquivo, "%d", &array[i]);
    }
    fclose(arquivo);
}

double acharMedia (int len, int * array)
{
    double total =0;
    for(int i = 0; i < len; i++)
    {
        total = total + array[i];
    }
     total = total / (double)len;

     return total;
}

void Exemplo0816()
{
    int len = 0;
    double media = 0.0;
    FILE* arquivo = fopen("DADOS.txt", "r");
    FILE* pares = fopen("paresMaiores.txt", "w");
    FILE* impares = fopen("imparesMenores.txt", "w");

    fscanf(arquivo, "%d", &len);
    fclose(arquivo);

    int array[len];
    lerArquivo("DADOS.txt", array);
    media = acharMedia(len, array);

    for(int i = 0; i<len; i++)
    {   //se e par
        if(even(array[i]))
        {   // e maior do que a media
            if(array[i] > media)
            {   //salva-lo no arquivo
                fprintf(pares, "%d\n", array[i]);
            }
        } else // se for impar
        {   //e menor do que a media
            if(array[i] < media)
            {   //salvar em outro arquivo
                fprintf(impares, "%d\n", array[i]);
            }
        }
    }

    fclose(pares);
    fclose(impares);
}

void Exemplo0817()
{
    int len = 0;
    int i = 0;
    bool decrescente = true;
    FILE* arquivo = fopen("DADOS.txt", "r");

    fscanf(arquivo, "%d", &len);
    fclose(arquivo);

    int array[len];
    lerArquivo("DADOS.txt", array);

    //caso nao seja descrescente ou tenha acabado o array
    while(decrescente && i < len)
    {
        //caso o proximo valor seja maior quer dizer que nao e descrescente
        if(array[i] < array[i+1])
        {
            decrescente = false;
        }
        i++;
    }

    if (decrescente)
    {
        printf("Array ordenado em ordem decrescente");
    } else
    {
        printf("Array nao e ordenado em ordem decrescente");
    }

}

// OBS.: FICARIA MELHOR COM FUNCAO.

void acharValorPar (int len, int * array, int procurado, int posiInicial)
{
    int i = posiInicial;
    bool achado = false;
    bool posiImpar = false;
    //enquanto o array nao acabar e nao tiver achado o valor
    while(i < len && !achado)
    {
        if(array[i] == procurado)
        {
            achado = true;
        }
        i++;
    }
    //checar se a posicao e par
    if(even(i-posiInicial))
    {
        posiImpar = true;
    }

    if(achado && posiImpar )
    {
        printf("Valor achado e em posicao impar");
    } else if (achado)
    {
        printf("Valor achado");
    } else
    {
        printf("Valor nao achado");
    }

}

void Exemplo0818()
{
    //variaveis
    int len = 0;
    int procurado = 0;
    int posiInicial = 0;
    FILE* arquivo = fopen("DADOS.txt", "r");
    //descobrir comprimento do array
    fscanf(arquivo, "%d", &len);
    fclose(arquivo);

    int array[len];
    lerArquivo("DADOS.txt", array);

    procurado = getInt("Valor a ser procurado: ");
    posiInicial = getInt("Posiciao inicial de procura: ");
    //chamar funcao
    acharValorPar(len, array, procurado, posiInicial);

}

// OBS.: FICARIA MELHOR COM FUNCAO.

void acharValorImpar (int len, int * array, int procurado, int posiInicial)
{
    int i = posiInicial;
    bool achado = false;
    bool posiPar = false;
    while(i < len && !achado)
    {
        if(array[i] == procurado)
        {
            achado = true;
        }
        i++;
    }

    if(!even(i-posiInicial))
    {
        posiPar = true;
    }

    if(achado && posiPar )
    {
        printf("Valor achado e em posicao par");
    } else if (achado)
    {
        printf("Valor achado");
    } else
    {
        printf("Valor nao achado");
    }

}

// OBS.: FICARIA MELHOR COM FUNCAO.

void Exemplo0819()
{
    int len = 0;
    int procurado = 0;
    int posiInicial = 0;
    FILE* arquivo = fopen("DADOS.txt", "r");

    fscanf(arquivo, "%d", &len);
    fclose(arquivo);

    int array[len];
    lerArquivo("DADOS.txt", array);

    procurado = getInt("Valor a ser procurado: ");
    posiInicial = getInt("Posiciao inicial de procura: ");

    acharValorImpar(len, array, procurado, posiInicial);

}

// OBS.: FICARIA MELHOR COM FUNCAO.

void acharQuantos (int len, int * array, int procurado, int posiInicial)
{
    int i = posiInicial;
    int qtdAchado = 0;
    bool achado = false;
    while(i < len)
    {
        if(array[i] == procurado)
        {
            achado = true;
            qtdAchado++;
        }
        i++;
    }

    if(achado && qtdAchado > 5 )
    {
        printf("Valor achado mais de 5x");
    } else if (achado)
    {
        printf("Valor achado");
    } else
    {
        printf("Valor nao achado");
    }

}

void Exemplo0820()
{
    int len = 0;
    int procurado = 0;
    int posiInicial = 0;
    FILE* arquivo = fopen("DADOS.txt", "r");

    fscanf(arquivo, "%d", &len);
    fclose(arquivo);

    int array[len];
    lerArquivo("DADOS.txt", array);

    procurado = getInt("Valor a ser procurado: ");
    posiInicial = getInt("Posiciao inicial de procura: ");

    acharQuantos(len, array, procurado, posiInicial);

}

void Exemplo08E1()
{
    int x = 0;
    int arPosi = 0;
    int arSize = 0;
    FILE* arquivo = fopen("DIVISORES.txt", "w");
    do
    {
        x = getInt("Entre com valor inteiro: ");
    }while (x == 0);

    //garantir que tamanho do array e positivo
    if(x < 0)
    {
        arSize = x * (-1);
    } else
    {
        arSize = x;
    }
    int array [arSize];

    //validar se e positivo ou negativo
    if(x > 0)
    {
        for(int i = x; i > 0; i--)
        {   //salvar divisores
            if(x%i == 0)
            {
                array[arPosi] = i;
                arPosi++;
            }
        }
    } else if ( x < 0)
    {
        for(int i = x; i < 0; i++)
        {
            if(x%i == 0)
            {
                array[arPosi] = i;
                arPosi++;
            }
        }
    }
    //printar divisores salvos no array
    for(int i = 0; i < arPosi; i++)
    {
        printf("%d\n", array[i]);
        fprintf(arquivo, "%d\n", array[i]);
    }
    fclose(arquivo);

}

void Exemplo08E2()
{
    //Usado para criar arquivo
    //FILE* arquivo = fopen("PALAVRAS.txt", "w");
    //fprintf(arquivo, "Arthur\narroz\nnariz\npera\nAmiga\nBicicleta");

    FILE* arquivo = fopen("PALAVRAS.txt", "r");
    char analise[140];
    int tamanho = 0;
    int wordCount = 0;

    fscanf(arquivo, "%140s", analise);

    while(!feof(arquivo) && wordCount<10)
    {
        tamanho = strlen(analise);
        if((analise[0] == 'A' || analise[0] == 'a') ||
            (analise[tamanho-1] == 'A' || analise[tamanho-1] == 'a'))
        {
            printf( "Palavra %d: %s\n", wordCount, analise);
            wordCount++;
        }
        fscanf(arquivo, "%140s", analise);
    }


    fclose(arquivo);

}

int main ( )
{
        // definir dado
    int x = 0;

    // repetir at� desejar parar
    do
    {
        // identificar
        IO_id ( "\n\nED08 - Programa - v0.0" );

        // ler do teclado
        IO_println ( "Opcoes" );
        IO_println ( "0 - parar" );
        IO_println ( "11 - Exemplo0811" );
        IO_println ( "12 - Exemplo0812");
        IO_println ( "13 - Exemplo0813");
        IO_println ( "14 - Exemplo0814");
        IO_println ( "15 - Exemplo0815");
        IO_println ( "16 - Exemplo0816");
        IO_println ( "17 - Exemplo0817");
        IO_println ( "18 - Exemplo0818");
        IO_println ( "19 - Exemplo0819");
        IO_println ( "20 - Exemplo0820");
        IO_println ( "21 - Exemplo08E1");
        IO_println ( "22 - Exemplo08E2");

        IO_println ( "" );

        x = getInt ( "Entrar com uma opcao: " );

        // testar valor
        switch ( x )
        {
            case 0:
                method00 ( );
                break;
            case 11:
                Exemplo0811 ( );
                break;
            case 12:
                Exemplo0812 ( );
                break;
            case 13:
                Exemplo0813 ( );
                break;
            case 14:
                Exemplo0814 ( );
                break;
            case 15:
                Exemplo0815 ( );
                break;
            case 16:
                Exemplo0816 ( );
                break;
            case 17:
                Exemplo0817 ( );
                break;
            case 18:
                Exemplo0818 ( );
                break;
            case 19:
                Exemplo0819 ( );
                break;
            case 20:
                Exemplo0820 ( );
                break;
            case 21:
                Exemplo08E1 ( );
                break;
            case 22:
                Exemplo08E2 ( );
                break;
            default:
            IO_pause ( "Valor diferente das opcoes"  );

        } // fim escolher
    }
    while ( x != 0 );

    // encerrar
    IO_pause ( "Apertar ENTER para terminar" );
    return ( 0 );
} // fim main( )
/*
---------------------------------------------- documentacao complementar


---------------------------------------------- notas / observacoes / comentarios


---------------------------------------------- previsao de testes
Exemplo0811
a.) quantidade - 2
    array - {0, 3} - dois valore invalidos e o programa continua pedindo ate que
                        dois valores validos sejam dados
Exemplo0812
a.) {1, 2, 3, 55, -3, -2, -3} > {1, 2, 3, 55, -2, 0, 0}
b.) {-3, -3, -3, -3, -3, -2, -3} > { -2, 0, 0, 0, 0, 0, 0}

Exemplo0813
a.) [5, 10] - 5 > {7, 5, 6, 8, 8}
b.) [-100, -1] - 5 > {-21, -18, -32, -17, -14}
c.) [-10, 10} - 6 > {-3, -10, 4, 9, 1, -4}

Exemplo0814
a.) {-3, -10, 4, 9, 1, -4} > -10
b.){385, 184, 211, 472, 460, 714, 214, 887, 439, 331} > 184

Exemplo0815
a.) {78, 71, 57, 64, 11} > 71
b.) {78, 78, 78, 64, 78} > Nao ha opcao valida

Exemplo0816
a.) { 53, 59, 82, 28, 59} > impar{53} e pares{82}
b.) { -21, 32, -32, -7, -96, 32, -63, -5, 45, 64} > impares {-21, -7, -63}
                                                    pares {32, 32, 64}
Exemplo0817
a.) { -21, 32, -32, -7, -96, 32, -63, -5, 45, 64} > nao ordenado
b.) {10, 8, 6, 4, 2} - ordenado
c.) {10, 8, 6, 10, 2} - nao ordenado

Exemplo0818
a.) array : {10, 8, 6, 10, 2}
    numero buscado: 10              >> valor encontrado em posiciao impar
    posiciao inicial: 2
b.) array : {10, 8, 6, 10, 2}
    numero buscado: 10              >> valor encontrado
    posiciao inicial: 0
c.) array : {10, 8, 6, 10, 2}
    numero buscado: 7              >> valor nao encontrado
    posiciao inicial: 0

Exemplo0819
a.) array : {10, 8, 6, 10, 2}
    numero buscado: 10              >> valor encontrado
    posiciao inicial: 2
b.) array : {10, 8, 6, 10, 2}
    numero buscado: 10              >> valor encontrado em posiciao par
    posiciao inicial: 0
c.) array : {10, 8, 6, 10, 2}
    numero buscado: 7              >> valor nao encontrado
    posiciao inicial: 0

Exemplo0820
a.) array : {5, 5, 5, 5, 5, 5}
    numero buscado: 5              >> valor encontrado mais de 5x
    posiciao inicial: 0
b.) array : {5, 5, 5, 5, 5, 5}
    numero buscado: 5              >> valor encontrado
    posiciao inicial: 0
c.) array : {5, 5, 5, 5, 5, 5}
    numero buscado: 7              >> valor nao encontrado
    posiciao inicial: 0

Exemplo08E1
a.) 6 - {6, 3, 2, 1}
b.) -6 - {-6, -3, -2, -1}
c.) 0 - invalido

Exemplo08E2
a.) Arthur             Arthur
    arroz               arroz
    nariz       >>
    pera                pera
    Amiga               Amiga
    Bicicleta           Bicicleta
b.) Arthur (x11) >> Arthur (x10)
c.) Nariz >> ""
---------------------------------------------- historico
Versao Data     Modificacao
1.1     28/09   esboco
1.2     28/09   esboco
1.3     28/09   esboco
1.4     28/09   esboco
1.5     28/09   esboco
1.6     28/09   esboco
1.7     28/09   esboco
1.8     28/09   esboco
1.9     28/09   esboco
2.0     28/09   esboco
E.1     28/09   esboco
E.2     28/09   esboco

---------------------------------------------- testes
Versao Teste
1.1     01.     (ok)    teste para aceitar apenas variaves validas
1.2     01.     (ok)    teste para abrir arquivo
1.3     01.     (ok)    teste com srand e rand
1.3     02.     (ok)    teste com rand() limitado
1.4     01.     (ok)    ler valores e avaliar diferentes valores de um array
1.5     01.     (ok)    Controlar casos invalidos
1.6     01.     (ok)    Criar dois arquivos
1.7     01.     (ok)    Checar dois valores do mesmo array
1.8     01.     (ok)    Procurar valor impar dentro de array
1.9     01.     (ok)    Validacao com teste
2.0     01.     (ok)    condicao do While()
E.1     01.     (ok)    Validacao do input
E.2     01.     (ok)    Checar palavra do arquivo;
*/
